1. CLick On the Index to view the home page.
2. Click on the Folder with the title "Learn-HTML-CSS-javascript" to view the following folders: Images, Other-Html and Style.
3. The "Images" Folder contains all the images that was used in the project.
4. The "Other-Html' contains the different pages created for the project. This Folder also contains the Folder "Javascript" which contains all the scripts used in the project.
5. The "Style" Folder includes all the CSS files used to style the HTML files.
6. Within the "Other-Html" folder click on introduction to go to the main JavaScrip page. This page includes sublinks linked to other pages.
7. The files containing the names: learnCss,learnHtml,LearnJS are files where users would be able to test their skills in coding based on the topic they choose.