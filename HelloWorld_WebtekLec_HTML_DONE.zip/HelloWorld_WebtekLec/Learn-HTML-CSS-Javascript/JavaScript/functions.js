var iframeOut = document.getElementById("output");

function ifrmOut() {
    iframeOut.srcdoc="<p>seks</p>"
}